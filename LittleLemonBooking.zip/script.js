
document.getElementById('bookingForm').addEventListener('submit', function(event) {
    event.preventDefault();

    let name = document.getElementById('name').value;
    let email = document.getElementById('email').value;
    let date = document.getElementById('date').value;
    let time = document.getElementById('time').value;
    let people = document.getElementById('people').value;
    let errorMessage = document.getElementById('errorMessage');

    // Basic validation
    if (name === "" || email === "" || date === "" || time === "" || people === "") {
        errorMessage.textContent = "Please fill in all the fields.";
        errorMessage.style.color = "red";
    } else if (people < 1) {
        errorMessage.textContent = "The number of people should be at least 1.";
        errorMessage.style.color = "red";
    } else {
        errorMessage.textContent = "";
        alert(`Booking Confirmed!\nName: ${name}\nEmail: ${email}\nDate: ${date}\nTime: ${time}\nPeople: ${people}`);
    }
});
